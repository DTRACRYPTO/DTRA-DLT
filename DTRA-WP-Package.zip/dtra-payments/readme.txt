
=== DTRA Payments ===
Contributors: dtra
Tags: crypto, bitcoin, ethereum, hedera, payments
Tested up to: 6.6
Stable tag: 0.1.1

Accept BTC, ETH (via Coinbase Commerce) and HBAR for DTRA at a fixed USD rate ($100 → 1 DTRA). Provides [dtra_buy] checkout and [dtra_marketplace] demo list.
